# Hospital Appointment Booking System - Spring Boot GUI + REST API

This is an Eclipse-importable Java Spring Boot project for a Hospital Appointment Booking System.
It includes both:

1. A browser-based GUI using Thymeleaf
2. A REST API using Spring Boot controllers

## Main Features

- Dashboard with total patients, doctors, appointments, and prescriptions
- Add and view patients
- Add and view doctors
- Book appointments
- Update appointment status: PENDING, ACCEPTED, REJECTED, COMPLETED
- Create prescriptions for appointments
- Delete records from GUI
- H2 in-memory database
- Spring Security with test users
- REST API endpoints are still available

## Technologies Used

- Java 17
- Spring Boot 3.3.5
- Spring Web
- Spring Data JPA
- Spring Security
- Thymeleaf
- H2 Database
- Maven

## How to Import in Eclipse

1. Extract this ZIP file.
2. Open Eclipse.
3. Go to `File > Import`.
4. Select `Maven > Existing Maven Projects`.
5. Click `Next`.
6. Browse and select the extracted project folder.
7. Select the `pom.xml` project.
8. Click `Finish`.
9. Wait for Maven dependencies to download.
10. Open `src/main/java/com/example/hospital/HospitalAppointmentApplication.java`.
11. Right-click and choose `Run As > Spring Boot App` or `Java Application`.

## Open the GUI

After running the project, open this URL in your browser:

```text
http://localhost:8080/gui/dashboard
```

You can also open:

```text
http://localhost:8080/
```

It will redirect to the GUI dashboard.

## GUI Pages

```text
Dashboard:      http://localhost:8080/gui/dashboard
Patients:       http://localhost:8080/gui/patients
Doctors:        http://localhost:8080/gui/doctors
Appointments:   http://localhost:8080/gui/appointments
Prescriptions:  http://localhost:8080/gui/prescriptions
```

## H2 Database Console

```text
http://localhost:8080/h2-console
```

Use these details:

```text
JDBC URL: jdbc:h2:mem:hospitaldb
Username: sa
Password: keep empty
```

## REST API Login Details

The GUI pages are open for easy project demonstration. REST API endpoints use Basic Auth.

```text
Admin:   admin / admin123
Doctor:  doctor / doctor123
Patient: patient / patient123
```

## Important Files Added for GUI

```text
src/main/java/com/example/hospital/HomeController.java
src/main/java/com/example/hospital/GuiController.java
src/main/resources/templates/dashboard.html
src/main/resources/templates/patients.html
src/main/resources/templates/doctors.html
src/main/resources/templates/appointments.html
src/main/resources/templates/prescriptions.html
src/main/resources/static/css/style.css
```

## Notes

- This project uses an in-memory H2 database, so data resets when the app restarts.
- Demo patients and doctors are inserted automatically when the app starts.
- If Maven dependencies do not download, right-click the project in Eclipse and select `Maven > Update Project`.

## Login Issue Fixed

This version opens the GUI directly without browser username/password popup.

Run the project and open:

```
http://localhost:8080/gui/dashboard
```

The REST API and H2 console are also accessible for demo/testing.



## Appointment date validation fix

The GUI now prevents past appointment date/time selection and shows a friendly error message instead of the long validation stack message.
