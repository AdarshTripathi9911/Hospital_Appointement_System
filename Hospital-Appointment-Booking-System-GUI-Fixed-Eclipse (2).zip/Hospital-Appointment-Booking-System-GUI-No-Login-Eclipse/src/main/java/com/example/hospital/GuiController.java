package com.example.hospital;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/gui")
public class GuiController {

    private final PatientService patientService;
    private final DoctorService doctorService;
    private final AppointmentService appointmentService;
    private final PrescriptionService prescriptionService;

    public GuiController(PatientService patientService,
                         DoctorService doctorService,
                         AppointmentService appointmentService,
                         PrescriptionService prescriptionService) {
        this.patientService = patientService;
        this.doctorService = doctorService;
        this.appointmentService = appointmentService;
        this.prescriptionService = prescriptionService;
    }

    @GetMapping({"", "/", "/dashboard"})
    public String dashboard(Model model) {
        List<Patient> patients = patientService.getAllPatients();
        List<Doctor> doctors = doctorService.getAllDoctors();
        List<Appointment> appointments = appointmentService.getAllAppointments();
        List<Prescription> prescriptions = prescriptionService.getAllPrescriptions();

        model.addAttribute("patientCount", patients.size());
        model.addAttribute("doctorCount", doctors.size());
        model.addAttribute("appointmentCount", appointments.size());
        model.addAttribute("prescriptionCount", prescriptions.size());
        model.addAttribute("latestAppointments", appointments.stream().limit(5).toList());
        return "dashboard";
    }

    @GetMapping("/patients")
    public String patients(Model model) {
        model.addAttribute("patients", patientService.getAllPatients());
        return "patients";
    }

    @PostMapping("/patients")
    public String addPatient(@RequestParam String name,
                             @RequestParam String email,
                             @RequestParam String phone,
                             @RequestParam Integer age,
                             @RequestParam String gender,
                             RedirectAttributes redirectAttributes) {
        try {
            patientService.createPatient(new PatientRequest(name, email, phone, age, gender));
            redirectAttributes.addFlashAttribute("success", "Patient added successfully.");
        } catch (Exception ex) {
            redirectAttributes.addFlashAttribute("error", ex.getMessage());
        }
        return "redirect:/gui/patients";
    }

    @GetMapping("/patients/delete/{id}")
    public String deletePatient(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            patientService.deletePatient(id);
            redirectAttributes.addFlashAttribute("success", "Patient deleted successfully.");
        } catch (Exception ex) {
            redirectAttributes.addFlashAttribute("error", ex.getMessage());
        }
        return "redirect:/gui/patients";
    }

    @GetMapping("/doctors")
    public String doctors(Model model) {
        model.addAttribute("doctors", doctorService.getAllDoctors());
        return "doctors";
    }

    @PostMapping("/doctors")
    public String addDoctor(@RequestParam String name,
                            @RequestParam String specialization,
                            @RequestParam String email,
                            @RequestParam String phone,
                            @RequestParam String availability,
                            RedirectAttributes redirectAttributes) {
        try {
            doctorService.createDoctor(new DoctorRequest(name, specialization, email, phone, availability));
            redirectAttributes.addFlashAttribute("success", "Doctor added successfully.");
        } catch (Exception ex) {
            redirectAttributes.addFlashAttribute("error", ex.getMessage());
        }
        return "redirect:/gui/doctors";
    }

    @GetMapping("/doctors/delete/{id}")
    public String deleteDoctor(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            doctorService.deleteDoctor(id);
            redirectAttributes.addFlashAttribute("success", "Doctor deleted successfully.");
        } catch (Exception ex) {
            redirectAttributes.addFlashAttribute("error", ex.getMessage());
        }
        return "redirect:/gui/doctors";
    }

    @GetMapping("/appointments")
    public String appointments(Model model) {
        model.addAttribute("appointments", appointmentService.getAllAppointments());
        model.addAttribute("patients", patientService.getAllPatients());
        model.addAttribute("doctors", doctorService.getAllDoctors());
        model.addAttribute("statuses", AppointmentStatus.values());
        model.addAttribute("minimumAppointmentDateTime", getMinimumAppointmentDateTime());
        return "appointments";
    }

    @PostMapping("/appointments")
    public String addAppointment(@RequestParam Long patientId,
                                 @RequestParam Long doctorId,
                                 @RequestParam String appointmentDateTime,
                                 @RequestParam String reason,
                                 RedirectAttributes redirectAttributes) {
        try {
            LocalDateTime dateTime = LocalDateTime.parse(appointmentDateTime);
            LocalDateTime minimumDateTime = LocalDateTime.now().plusMinutes(1).withSecond(0).withNano(0);

            if (dateTime.isBefore(minimumDateTime)) {
                redirectAttributes.addFlashAttribute("error", "Please select a future date and time for the appointment.");
                return "redirect:/gui/appointments";
            }

            appointmentService.bookAppointment(new AppointmentRequest(patientId, doctorId, dateTime, reason));
            redirectAttributes.addFlashAttribute("success", "Appointment booked successfully.");
        } catch (Exception ex) {
            redirectAttributes.addFlashAttribute("error", "Unable to book appointment. Please check all fields and select a future date/time.");
        }
        return "redirect:/gui/appointments";
    }

    @PostMapping("/appointments/{id}/status")
    public String updateAppointmentStatus(@PathVariable Long id,
                                          @RequestParam AppointmentStatus status,
                                          @RequestParam(required = false) String doctorNotes,
                                          RedirectAttributes redirectAttributes) {
        try {
            appointmentService.updateAppointmentStatus(id, new AppointmentStatusRequest(status, doctorNotes));
            redirectAttributes.addFlashAttribute("success", "Appointment status updated.");
        } catch (Exception ex) {
            redirectAttributes.addFlashAttribute("error", ex.getMessage());
        }
        return "redirect:/gui/appointments";
    }

    @GetMapping("/appointments/delete/{id}")
    public String deleteAppointment(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            appointmentService.cancelAppointment(id);
            redirectAttributes.addFlashAttribute("success", "Appointment deleted successfully.");
        } catch (Exception ex) {
            redirectAttributes.addFlashAttribute("error", ex.getMessage());
        }
        return "redirect:/gui/appointments";
    }

    @GetMapping("/prescriptions")
    public String prescriptions(Model model) {
        model.addAttribute("prescriptions", prescriptionService.getAllPrescriptions());
        model.addAttribute("appointments", appointmentService.getAllAppointments());
        return "prescriptions";
    }

    @PostMapping("/prescriptions")
    public String addPrescription(@RequestParam Long appointmentId,
                                  @RequestParam String medicineDetails,
                                  @RequestParam(required = false) String advice,
                                  RedirectAttributes redirectAttributes) {
        try {
            prescriptionService.createPrescription(new PrescriptionRequest(appointmentId, medicineDetails, advice));
            redirectAttributes.addFlashAttribute("success", "Prescription created successfully.");
        } catch (Exception ex) {
            redirectAttributes.addFlashAttribute("error", ex.getMessage());
        }
        return "redirect:/gui/prescriptions";
    }

    @GetMapping("/prescriptions/delete/{id}")
    public String deletePrescription(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            prescriptionService.deletePrescription(id);
            redirectAttributes.addFlashAttribute("success", "Prescription deleted successfully.");
        } catch (Exception ex) {
            redirectAttributes.addFlashAttribute("error", ex.getMessage());
        }
        return "redirect:/gui/prescriptions";
    }

    private String getMinimumAppointmentDateTime() {
        return LocalDateTime.now()
                .plusMinutes(1)
                .withSecond(0)
                .withNano(0)
                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm"));
    }
}
