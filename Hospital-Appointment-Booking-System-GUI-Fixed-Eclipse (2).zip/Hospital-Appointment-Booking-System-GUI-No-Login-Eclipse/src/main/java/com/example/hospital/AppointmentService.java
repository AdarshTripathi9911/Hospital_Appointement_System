package com.example.hospital;

import jakarta.persistence.*;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.http.*;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.*;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.*;

@Service
public class AppointmentService {

    private final AppointmentRepository appointmentRepository;
    private final PatientService patientService;
    private final DoctorService doctorService;

    AppointmentService(AppointmentRepository appointmentRepository,
                       PatientService patientService,
                       DoctorService doctorService) {
        this.appointmentRepository = appointmentRepository;
        this.patientService = patientService;
        this.doctorService = doctorService;
    }

    List<Appointment> getAllAppointments() {
        return appointmentRepository.findAll();
    }

    Appointment getAppointmentById(Long id) {
        return appointmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Appointment not found with id: " + id));
    }

    List<Appointment> getAppointmentsByPatient(Long patientId) {
        patientService.getPatientById(patientId);
        return appointmentRepository.findByPatientId(patientId);
    }

    List<Appointment> getAppointmentsByDoctor(Long doctorId) {
        doctorService.getDoctorById(doctorId);
        return appointmentRepository.findByDoctorId(doctorId);
    }

    List<Appointment> getAppointmentsByStatus(AppointmentStatus status) {
        return appointmentRepository.findByStatus(status);
    }

    Appointment bookAppointment(AppointmentRequest request) {
        if (request.appointmentDateTime() == null || request.appointmentDateTime().isBefore(LocalDateTime.now())) {
            throw new IllegalArgumentException("Appointment date and time must be in the present or future.");
        }

        Patient patient = patientService.getPatientById(request.patientId());
        Doctor doctor = doctorService.getDoctorById(request.doctorId());

        Appointment appointment = new Appointment(
                patient,
                doctor,
                request.appointmentDateTime(),
                request.reason()
        );

        return appointmentRepository.save(appointment);
    }

    Appointment updateAppointmentStatus(Long id, AppointmentStatusRequest request) {
        Appointment appointment = getAppointmentById(id);
        appointment.setStatus(request.status());
        appointment.setDoctorNotes(request.doctorNotes());
        return appointmentRepository.save(appointment);
    }

    void cancelAppointment(Long id) {
        Appointment appointment = getAppointmentById(id);

        if (appointment.getStatus() == AppointmentStatus.COMPLETED) {
            throw new IllegalArgumentException("Completed appointment cannot be cancelled.");
        }

        appointmentRepository.delete(appointment);
    }
}
