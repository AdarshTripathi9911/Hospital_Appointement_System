package com.example.hospital;

import jakarta.persistence.*;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.http.*;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.*;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.*;

@Service
public class PrescriptionService {

    private final PrescriptionRepository prescriptionRepository;
    private final AppointmentRepository appointmentRepository;
    private final AppointmentService appointmentService;

    PrescriptionService(PrescriptionRepository prescriptionRepository,
                        AppointmentRepository appointmentRepository,
                        AppointmentService appointmentService) {
        this.prescriptionRepository = prescriptionRepository;
        this.appointmentRepository = appointmentRepository;
        this.appointmentService = appointmentService;
    }

    List<Prescription> getAllPrescriptions() {
        return prescriptionRepository.findAll();
    }

    Prescription getPrescriptionById(Long id) {
        return prescriptionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Prescription not found with id: " + id));
    }

    Prescription getPrescriptionByAppointmentId(Long appointmentId) {
        return prescriptionRepository.findByAppointmentId(appointmentId)
                .orElseThrow(() -> new ResourceNotFoundException("Prescription not found for appointment id: " + appointmentId));
    }

    Prescription createPrescription(PrescriptionRequest request) {
        Appointment appointment = appointmentService.getAppointmentById(request.appointmentId());

        if (appointment.getStatus() == AppointmentStatus.REJECTED) {
            throw new IllegalArgumentException("Prescription cannot be created for rejected appointment.");
        }

        if (prescriptionRepository.findByAppointmentId(request.appointmentId()).isPresent()) {
            throw new IllegalArgumentException("Prescription already exists for this appointment.");
        }

        appointment.setStatus(AppointmentStatus.COMPLETED);
        appointmentRepository.save(appointment);

        Prescription prescription = new Prescription(
                appointment,
                request.medicineDetails(),
                request.advice()
        );

        return prescriptionRepository.save(prescription);
    }

    Prescription updatePrescription(Long id, PrescriptionRequest request) {
        Prescription prescription = getPrescriptionById(id);
        prescription.setMedicineDetails(request.medicineDetails());
        prescription.setAdvice(request.advice());
        return prescriptionRepository.save(prescription);
    }

    void deletePrescription(Long id) {
        Prescription prescription = getPrescriptionById(id);
        prescriptionRepository.delete(prescription);
    }
}
