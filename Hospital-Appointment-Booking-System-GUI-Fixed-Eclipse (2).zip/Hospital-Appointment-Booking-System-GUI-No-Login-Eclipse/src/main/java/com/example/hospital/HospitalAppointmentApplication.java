package com.example.hospital;

import jakarta.persistence.*;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.http.*;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.*;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.*;

// MAIN CLASS
@SpringBootApplication
public class HospitalAppointmentApplication {
    public static void main(String[] args) {
        SpringApplication.run(HospitalAppointmentApplication.class, args);
    }

    @Bean
    CommandLineRunner seedData(PatientRepository patientRepository, DoctorRepository doctorRepository) {
        return args -> {
            if (patientRepository.count() == 0) {
                patientRepository.save(new Patient("Amit Sharma", "amit@example.com", "9876543210", 25, "Male"));
                patientRepository.save(new Patient("Priya Singh", "priya@example.com", "9876543211", 29, "Female"));
            }

            if (doctorRepository.count() == 0) {
                doctorRepository.save(new Doctor(
                        "Dr. Neha Verma",
                        "Cardiology",
                        "neha.verma@hospital.com",
                        "9876500001",
                        "Mon-Fri 10 AM - 2 PM"
                ));

                doctorRepository.save(new Doctor(
                        "Dr. Raj Mehta",
                        "Dermatology",
                        "raj.mehta@hospital.com",
                        "9876500002",
                        "Tue-Sat 4 PM - 8 PM"
                ));
            }
        };
    }
}
